#include "test.h"
atomic_int state;
