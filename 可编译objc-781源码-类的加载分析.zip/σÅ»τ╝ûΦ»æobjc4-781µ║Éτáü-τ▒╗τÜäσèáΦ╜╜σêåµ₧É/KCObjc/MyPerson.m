//
//  LGPerson.m
//  KCObjc
//
//  Created by Cooci on 2020/7/24.
//

#import "MyPerson.h"
#import <objc/runtime.h>

@interface MyPerson ()
@property (nonatomic, copy) NSString *ext_name;
- (void)ext_instanceMthod1;
+ (void)ext_classMthod1;
@end


@implementation MyPerson

//+ (void)load {
//    
//}

- (void)ext_instanceMthod1{
    
}
+ (void)ext_classMthod1{
    
}


- (void)funcInstanceTest {
    NSLog(@"hello, funcInstanceTest");

}
- (void)helloObj1 {
    NSLog(@"hello, helloObj1");
}

+ (void)funcClassTest {
    NSLog(@"hello, funcClassTest");

}


///==================  动态方法决议  ====================
//+ (BOOL)resolveInstanceMethod:(SEL)sel {
//
////    if (sel == @selector(helloObj7)) {
////
////        NSLog(@"对 helloObj7 进行处理吧");
////        // class_getMethodImplementation(Class  _Nullable __unsafe_unretained cls, SEL  _Nonnull name)
////        IMP imp = class_getMethodImplementation(self, @selector(my_resolveHello7));
////
////        // 下面两行为了拿到: "v@:"
//////        Method m = class_getInstanceMethod(self, @selector(my_resolveHello7));
//////        const char *encodeType = method_getTypeEncoding(m);
////        // class_addMethod(Class  _Nullable __unsafe_unretained cls, SEL  _Nonnull name, IMP  _Nonnull imp, const char * _Nullable types)
////        return class_addMethod(self, sel, imp, "v@:");
////    }
//
//    NSLog(@"来到 resolveInstanceMethod 了");
//    return [super resolveInstanceMethod:sel];
//}
//- (void)my_resolveHello7 {
//
//    NSLog(@"我是hello7的resolve");
//}




///==================   消息转发  ===================
/////快速消息转发
//- (id)forwardingTargetForSelector:(SEL)aSelector {
//    
//    NSLog(@"快速转发这里需要 sel == %@",NSStringFromSelector(aSelector));
////    return [super forwardingTargetForSelector:aSelector];
//    return self;
//}


/////消息签名
//- (NSMethodSignature *)methodSignatureForSelector:(SEL)aSelector {
//    NSLog(@"需要消息签名 sel == %@",NSStringFromSelector(aSelector));
////    return [super methodSignatureForSelector:aSelector];
//    // 给一个方法签名
//    // v@: --> 返回类型void，参数类型id,SEL
//    return [NSMethodSignature signatureWithObjCTypes:"v@:"];
//}
//- (void)forwardInvocation:(NSInvocation *)anInvocation {// Invocation 启用
//    NSLog(@"签名过来了");
//
//    anInvocation.target = self;
//    anInvocation.selector = @selector(funcInstanceTest);// @selector(helloObj7);
//    [anInvocation invoke];
//    /**
//     执行结果
//     需要消息签名 sel == helloObj7
//     签名过来了
//     hello, funcInstanceTest
//     */
//
//
////    NSLog(@"anInvocation == %@",anInvocation);
////    NSLog(@"anInvocation.target == %@",anInvocation.target);
////    NSLog(@"anInvocation.selector == %@",NSStringFromSelector(anInvocation.selector));
//
//}


//+ (NSMethodSignature *)instanceMethodSignatureForSelector:(SEL)aSelector {
//
//    NSLog(@"消息签名 sel == %@",NSStringFromSelector(aSelector));
//    return [super instanceMethodSignatureForSelector:aSelector];
//}

@end
