//
//  MyPerson+cateTwo.m
//  KCObjc
//
//  Created by Domy on 2020/10/21.
//

#import "MyPerson+cateTwo.h"

#import <AppKit/AppKit.h>


@implementation MyPerson (cateTwo)

//+ (void)load {
//    
//}

- (void)helloObj1 {
    NSLog(@"hello, helloObj1-cateTwo");
}

- (void)helloCateTwoInstance {
    NSLog(@"hello, helloCateTwoInstance");
}
+ (void)helloCateTwoClass{
    NSLog(@"hello, helloCateTwoClass");
}

@end
