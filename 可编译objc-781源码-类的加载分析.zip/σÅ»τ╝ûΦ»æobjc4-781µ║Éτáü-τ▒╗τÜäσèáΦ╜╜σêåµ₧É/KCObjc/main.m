//
//  main.m
//  KCObjc
//
//  Created by Cooci on 2020/7/24.
//

#import <Foundation/Foundation.h>
#import "MyPerson.h"



//@interface MyPerson (cateMore)
//
//@property (nonatomic, strong) NSString *cate_name;
//@property (nonatomic, assign) NSInteger cate_age;
//
//- (void)helloObj2;
//- (void)helloObj3;
//- (void)helloObj4;
//+ (void)helloClass1;
//
//@end
//@implementation MyPerson (cateMore)
//
//- (void)helloObj2 {
//    NSLog(@"hello, helloObj2");
//}
//- (void)helloObj3 {
//    NSLog(@"hello, helloObj3");
//}
//- (void)helloObj4 {
//    NSLog(@"hello, helloObj4");
//}
//+ (void)helloClass1 {
//    NSLog(@"hello, helloClass1");
//}
//
//@end

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        
        NSObject *objc1 = [[NSObject alloc] init];
        MyPerson *objc2 = [MyPerson alloc];
        [objc2 helloObj1];
        NSLog(@"Hello, World! %@ - %@",objc1,objc2);
    }// OBJC_DISABLE_NONPOINTER_ISA    OBJC_PRINT_LOAD_METHODS
    return 0;
}
