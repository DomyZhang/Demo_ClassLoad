//
//  LGPerson.h
//  KCObjc
//
//  Created by Cooci on 2020/7/24.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MyPerson : NSObject {
   
    NSString *instName;

//    NSObject *obj;
//    MyPerson *person1;
//    UIButton *btn;
}


@property (nonatomic, copy) NSString *propName;
@property (nonatomic, strong) NSString *testpName;
@property (nonatomic, assign) NSInteger age;

- (void)funcInstanceTest;
- (void)helloObj1;
+ (void)funcClassTest;



@end

NS_ASSUME_NONNULL_END
