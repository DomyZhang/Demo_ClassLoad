//
//  MyPerson+cateMore.h
//  KCObjc
//
//  Created by Domy on 2020/10/20.
//

#import <AppKit/AppKit.h>


#import "MyPerson.h"

NS_ASSUME_NONNULL_BEGIN

@interface MyPerson (cateMore)

- (void)helloObj2;

+ (void)helloClass1;

@end

NS_ASSUME_NONNULL_END
