//
//  MyPerson+cateMore.m
//  KCObjc
//
//  Created by Domy on 2020/10/20.
//

#import "MyPerson+cateMore.h"

#import <AppKit/AppKit.h>

@implementation MyPerson (cateMore)

//+ (void)load {
//    
//}

- (void)helloObj1 {
    NSLog(@"hello, helloObj1-cateMore");
}

- (void)helloObj2 {
    NSLog(@"hello, helloObj2");
}

+ (void)helloClass1 {
    NSLog(@"hello, helloClass1");
}


@end
